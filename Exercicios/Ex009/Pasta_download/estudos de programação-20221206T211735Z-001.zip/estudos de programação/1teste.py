pi=3.14
raio=5
area=pi*raio
print(area)
